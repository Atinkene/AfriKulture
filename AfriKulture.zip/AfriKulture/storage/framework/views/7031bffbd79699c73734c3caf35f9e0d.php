<?php $__env->startSection('content'); ?>
    <div class="w-[95%] m-auto max-h-screen overflow-visible mt-20">
       <div class="space-y-5  w-full bg-white">
            <span class="font-bold text-blue-900 text-lg flex justify-center items-center">
                Bonjour <?php echo e(Auth()->user()->prenom.' '.Auth()->user()->nom); ?>!
            </span>
            
            
       </div>
       
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/massina/Bureau/DefarSci/AfriKulture/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>