<?php $__env->startSection('content'); ?>
    <div class="w-[95%] m-auto max-h-screen overflow-visible mt-20">
       <div class="w-full bg-white">
            <span class="font-bold text-blue-900 text-lg flex justify-center items-center">
                Mes Parties en attente
            </span>
            
            <table class="mt-5 shadow-md shadow-blue-900/400 rounded-bl-2xl rounded-th-2xl space-y-10 w-full pb-5 p-5">
                <thead class="bg-blue-900 h-10 text-white shadow-md shadow-blue-900/400">
                    <th>Nom</th>
                    <th>Date</th>
                    <th>Heure</th>
                    <th>Durée</th>
                </thead>
                <tbody class="text-center ">
                    <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class=" h-12 rounded-lg">
                            <td class="font-bold"><a href="<?php echo e(route('traitementPartie',$partie->id)); ?>"><?php echo e($partie->nom); ?></a></td>
                            <td class=""><?php echo e($partie->dateDebut); ?></td>
                            <td class=""><?php echo e($partie->HeureDebut); ?></td>
                            <td class=""><?php echo e($partie->duree); ?> mn(s)</td>                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
       </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('joueur.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/massina/Bureau/DefarSci/AfriKulture/resources/views/joueur/partiesAvenir.blade.php ENDPATH**/ ?>