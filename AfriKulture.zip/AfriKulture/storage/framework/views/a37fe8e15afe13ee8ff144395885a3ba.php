<div class="flex flex-col items-center justify-center h-screen">
    <h1 class="text-6xl font-bold text-blue-900">Bienvenue sur AfriKulture!</h1>
    <h3 class="text-blue-900">votre plateforme de jeu de culture générale africain</h3>
</div>
<?php /**PATH /home/massina/Bureau/DefarSci/AfriKulture/resources/views/afrikulture/composants/welcome.blade.php ENDPATH**/ ?>